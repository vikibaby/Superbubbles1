//
/*Yiqi li programs this part*/
//

#include "DetectSuperBubble.hpp"


namespace supbub {

    void
    DetectSuperBubble::find(Graph& g,SUPERBUBBLE_LIST& superBubblesList){

        int64_t numVertices = g.numVertices();

        std::set<int64_t> se=g.getNodeSet();//line1
        std::set<int64_t>::iterator si;


        for(si=se.begin(); si!= se.end(); ++si) {//line2
            
            std::stack<int64_t> S;
            S.push(*si);// si is set, S is strack
//std::cout<<std::endl<<"Si::(bigfor)"<<S.top()<<std::endl;
            bool* visited = new bool[numVertices];
                 std::fill_n( visited, numVertices, 0 ); // set to false  
            std::set<int64_t> setCheck;//set   
            while ( !S.empty() )
          
              {
                        
                 int64_t v;
                 v=S.top();
                 S.pop();      
                 if(visited[v] == true){{/*std::cout<<v<<"been visted again"<<std::endl;*/break;}}
                 else {visited[v] = true;
//std::cout<<"CCCCCCCCCCCCCCCCsetChecksize"<<setCheck.size()<<std::endl; 
                      setCheck.erase(v);
//std::cout<<"CCCCCCCCCCCCCCCCsetChecksize"<<setCheck.size()<<std::endl; 

                      }
//std::cout<<std::endl<<v<<" IS visited(while)"<<std::endl;
                 int64_t* superBubblesArray = new int64_t[numVertices];
                 int64_t_LIST& children = g.getChildren(v);
                 int64_t_LIST& vparents = g.getParents(v);
                 if (children.empty()){/*std::cout<<v<<", doesnot have a child"<<std::endl;*/break;}//line5
                 //std::cout<<"v: "<<v<<std::endl;
                
                 int64_t checkPush;
                
       
        
                 int64_t_LIST_ITERATOR u;
                 for (u = children.begin(); u != children.end(); ++u) {//line7
                     //bool* seen = new bool[numVertices];
                     //std::fill_n( seen, numVertices, 0 ); // set to false 

                     //std::cout<<"One of u (children of v) is :"<<*u<<std::endl;
                     if(*u == v){/*std::cout<<"v pionter to itself."<<std::endl;*/break;}//line8
//std::cout<<"CCCCCCCCCCCCCCCCsetChecksize"<<setCheck.size()<<std::endl;  
                     setCheck.insert(*u);
//std::cout<<"CCCCCCCCCCCCCCCCsetChecksize"<<setCheck.size()<<std::endl;                  
                     //seen[*u]=true; //line10
//std::cout<<*u<<" is seen"<<std::endl;
                     //if(visited[*u] == true){{std::cout<<v<<"bbbeen visted again"<<std::endl;break;}}
                     
                     int64_t kengdie;
                     kengdie=*u;
                     int64_t_LIST& parentOfu= g.getParents(kengdie);
//std::cout<<"parents1 is"<<*parentOfu.begin()<<std::endl;
//std::cout<<"parents2 is"<<*parentOfu.end()<<std::endl;
 
                     
                     //std::cout<<" U parentslistsize: "<<parentOfu.size()<<std::endl;
                     int d; 
                     int64_t_LIST_ITERATOR i1;
                     if (! parentOfu.empty()) {//line11
                         if(parentOfu.size()==1){S.push(*u);/*std::cout<<"First push"<<*u<<std::endl;*/}
                         else{
                              for (i1 = parentOfu.begin(),d=0; d < parentOfu.size(); ++i1,++d) {
//std::cout<<"the parentOfu: "<<*i1<<std::endl;
                                   if (!visited[*i1]) {/*std::cout<<"Its parent unvisited"<<std::endl;*/
                                     break;
                                   }//line11 endif
                                   //(*i1 == *parentOfu.end()) {S.push(*u);std::cout<<"2push"<<*u<<std::endl;}
                              }
                              if (d == parentOfu.size()) {S.push(*u);/*std::cout<<"Second push"<<*u<<std::endl;*/}
                         }                   
                     }
//std::cout<<"End samell For zzzzzzU"<<*u<<std::endl;
checkPush = *u;    
//std::cout<<"End samell For U"<<std::endl;
                }//small for


                if (S.size() == 1 && /*children.size()==1 &&*/ S.top()==checkPush && setCheck.size() ==1){ //line13
//std::cout<<"End samell For check"<<checkPush<<std::endl;
//std::cout<<"line13"<<std::endl;     
                     int64_t t;
                     t = S.top();

                     if(visited[t] == true){/*std::cout<<v<<"bbbeen visted again"<<std::endl;*/break;}
//std::cout<<"si:"<<*si<<std::endl;
//std::cout<<"v:"<<v<<std::endl;
//std::cout<<"t:"<<t<<std::endl;
//superBubblesList.push_back(SuperBubble{*si, v});

                     int64_t_LIST& parentsOfSi = g.getParents(*si);
                     if(parentsOfSi.empty()){
//std::cout<<"ReportSuperBubbleeeeeeeeeeeeeee"<<std::endl;
                        superBubblesList.push_back(SuperBubble{*si, t});
break;}                    
                     else {
                           int64_t_LIST_ITERATOR i3;
                           for(i3 = parentsOfSi.begin(); i3 != parentsOfSi.end(); ++i3){
                              if(*i3==t){/*std::cout<<"circle!!!"<<std::endl;*/break;};
                           }
                            if(parentsOfSi.end()==i3 ){  
//std::cout<<"RRRRRRRRRRRRRRRRRRRReportSuperBubble"<<std::endl;                  
                             superBubblesList.push_back(SuperBubble{*si, t});
break;
                           }
                     }//end if
                     
               }
//std::cout<<"End While"<<std::endl;                  
}//end while
//std::cout<<"End Big For"<<std::endl;                  
}//end big for
}//end function
}//end namespace


